export interface TagDTO {
  tag_id: number;
  name: string;
  nicename: string;
}
